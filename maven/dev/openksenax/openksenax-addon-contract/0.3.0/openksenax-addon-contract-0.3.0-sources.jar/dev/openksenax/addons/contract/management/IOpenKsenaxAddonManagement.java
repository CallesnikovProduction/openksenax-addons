/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: D:\\Android\\Sdk\\build-tools\\36.0.0\\aidl.exe -pD:\\Android\\Sdk\\platforms\\android-36.1\\framework.aidl -oC:\\KsetaAgentic-Application-Project\\addon-contract\\build\\generated\\aidl_source_output_dir\\release\\out -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\release\\aidl -dC:\\Users\\������\\AppData\\Local\\Temp\\aidl8057504995266763486.d C:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl\\dev\\openksenax\\addons\\contract\\management\\IOpenKsenaxAddonManagement.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package dev.openksenax.addons.contract.management;
/** Asynchronous Binder API for an autonomous add-on APK. @since 0.3 */
public interface IOpenKsenaxAddonManagement extends android.os.IInterface
{
  /** Default implementation for IOpenKsenaxAddonManagement. */
  public static class Default implements dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement
  {
    /** Requests the current runtime state. */
    @Override public void requestRuntimeStatus(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
    {
    }
    /** Requests a runtime enabled-state change. */
    @Override public void requestSetEnabled(java.lang.String requestId, boolean enabled, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
    {
    }
    /** Requests the add-on-owned UI entry point. */
    @Override public void requestUiEntryPoint(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
    {
    }
    /** Best-effort cancellation of a previous request. */
    @Override public void cancel(java.lang.String requestId) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement interface,
     * generating a proxy if needed.
     */
    public static dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement))) {
        return ((dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement)iin);
      }
      return new dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_requestRuntimeStatus:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          dev.openksenax.addons.contract.management.IAddonManagementCallback _arg1;
          _arg1 = dev.openksenax.addons.contract.management.IAddonManagementCallback.Stub.asInterface(data.readStrongBinder());
          this.requestRuntimeStatus(_arg0, _arg1);
          break;
        }
        case TRANSACTION_requestSetEnabled:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          dev.openksenax.addons.contract.management.IAddonManagementCallback _arg2;
          _arg2 = dev.openksenax.addons.contract.management.IAddonManagementCallback.Stub.asInterface(data.readStrongBinder());
          this.requestSetEnabled(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_requestUiEntryPoint:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          dev.openksenax.addons.contract.management.IAddonManagementCallback _arg1;
          _arg1 = dev.openksenax.addons.contract.management.IAddonManagementCallback.Stub.asInterface(data.readStrongBinder());
          this.requestUiEntryPoint(_arg0, _arg1);
          break;
        }
        case TRANSACTION_cancel:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.cancel(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** Requests the current runtime state. */
      @Override public void requestRuntimeStatus(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(requestId);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_requestRuntimeStatus, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /** Requests a runtime enabled-state change. */
      @Override public void requestSetEnabled(java.lang.String requestId, boolean enabled, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(requestId);
          _data.writeInt(((enabled)?(1):(0)));
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_requestSetEnabled, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /** Requests the add-on-owned UI entry point. */
      @Override public void requestUiEntryPoint(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(requestId);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_requestUiEntryPoint, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      /** Best-effort cancellation of a previous request. */
      @Override public void cancel(java.lang.String requestId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(requestId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancel, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_requestRuntimeStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_requestSetEnabled = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_requestUiEntryPoint = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_cancel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "dev.openksenax.addons.contract.management.IOpenKsenaxAddonManagement";
  /** Requests the current runtime state. */
  public void requestRuntimeStatus(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException;
  /** Requests a runtime enabled-state change. */
  public void requestSetEnabled(java.lang.String requestId, boolean enabled, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException;
  /** Requests the add-on-owned UI entry point. */
  public void requestUiEntryPoint(java.lang.String requestId, dev.openksenax.addons.contract.management.IAddonManagementCallback callback) throws android.os.RemoteException;
  /** Best-effort cancellation of a previous request. */
  public void cancel(java.lang.String requestId) throws android.os.RemoteException;
}

/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: D:\\Android\\Sdk\\build-tools\\36.0.0\\aidl.exe -pD:\\Android\\Sdk\\platforms\\android-36.1\\framework.aidl -oC:\\KsetaAgentic-Application-Project\\addon-contract\\build\\generated\\aidl_source_output_dir\\release\\out -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\release\\aidl -dC:\\Users\\������\\AppData\\Local\\Temp\\aidl99532087624189589.d C:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl\\dev\\openksenax\\addons\\contract\\model\\IModelGenerationCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package dev.openksenax.addons.contract.model;
/** One-shot model provider callback. @since 0.3 */
public interface IModelGenerationCallback extends android.os.IInterface
{
  /** Default implementation for IModelGenerationCallback. */
  public static class Default implements dev.openksenax.addons.contract.model.IModelGenerationCallback
  {
    @Override public void onCompleted(dev.openksenax.addons.contract.model.ModelGenerationResult result) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements dev.openksenax.addons.contract.model.IModelGenerationCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an dev.openksenax.addons.contract.model.IModelGenerationCallback interface,
     * generating a proxy if needed.
     */
    public static dev.openksenax.addons.contract.model.IModelGenerationCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof dev.openksenax.addons.contract.model.IModelGenerationCallback))) {
        return ((dev.openksenax.addons.contract.model.IModelGenerationCallback)iin);
      }
      return new dev.openksenax.addons.contract.model.IModelGenerationCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onCompleted:
        {
          dev.openksenax.addons.contract.model.ModelGenerationResult _arg0;
          _arg0 = _Parcel.readTypedObject(data, dev.openksenax.addons.contract.model.ModelGenerationResult.CREATOR);
          this.onCompleted(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements dev.openksenax.addons.contract.model.IModelGenerationCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onCompleted(dev.openksenax.addons.contract.model.ModelGenerationResult result) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, result, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onCompleted, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onCompleted = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "dev.openksenax.addons.contract.model.IModelGenerationCallback";
  public void onCompleted(dev.openksenax.addons.contract.model.ModelGenerationResult result) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}

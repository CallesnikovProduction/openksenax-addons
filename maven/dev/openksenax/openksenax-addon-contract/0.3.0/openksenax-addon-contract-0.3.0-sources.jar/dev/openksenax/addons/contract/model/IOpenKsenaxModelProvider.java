/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: D:\\Android\\Sdk\\build-tools\\36.0.0\\aidl.exe -pD:\\Android\\Sdk\\platforms\\android-36.1\\framework.aidl -oC:\\KsetaAgentic-Application-Project\\addon-contract\\build\\generated\\aidl_source_output_dir\\release\\out -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl -IC:\\KsetaAgentic-Application-Project\\addon-contract\\src\\release\\aidl -dC:\\Users\\������\\AppData\\Local\\Temp\\aidl7885885943315759324.d C:\\KsetaAgentic-Application-Project\\addon-contract\\src\\main\\aidl\\dev\\openksenax\\addons\\contract\\model\\IOpenKsenaxModelProvider.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package dev.openksenax.addons.contract.model;
/** IPC access from a trusted add-on APK to the OpenKsenax model provider. @since 0.3 */
public interface IOpenKsenaxModelProvider extends android.os.IInterface
{
  /** Default implementation for IOpenKsenaxModelProvider. */
  public static class Default implements dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider
  {
    @Override public int getProviderApiVersion() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public java.lang.String[] getAvailableCapabilities() throws android.os.RemoteException
    {
      return null;
    }
    @Override public void generate(dev.openksenax.addons.contract.model.ModelGenerationRequest request, dev.openksenax.addons.contract.model.IModelGenerationCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void cancel(java.lang.String requestId) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider interface,
     * generating a proxy if needed.
     */
    public static dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider))) {
        return ((dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider)iin);
      }
      return new dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getProviderApiVersion:
        {
          int _result = this.getProviderApiVersion();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_getAvailableCapabilities:
        {
          java.lang.String[] _result = this.getAvailableCapabilities();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_generate:
        {
          dev.openksenax.addons.contract.model.ModelGenerationRequest _arg0;
          _arg0 = _Parcel.readTypedObject(data, dev.openksenax.addons.contract.model.ModelGenerationRequest.CREATOR);
          dev.openksenax.addons.contract.model.IModelGenerationCallback _arg1;
          _arg1 = dev.openksenax.addons.contract.model.IModelGenerationCallback.Stub.asInterface(data.readStrongBinder());
          this.generate(_arg0, _arg1);
          break;
        }
        case TRANSACTION_cancel:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.cancel(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public int getProviderApiVersion() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getProviderApiVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getAvailableCapabilities() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getAvailableCapabilities, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void generate(dev.openksenax.addons.contract.model.ModelGenerationRequest request, dev.openksenax.addons.contract.model.IModelGenerationCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_generate, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void cancel(java.lang.String requestId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(requestId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancel, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_getProviderApiVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_getAvailableCapabilities = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_generate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_cancel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "dev.openksenax.addons.contract.model.IOpenKsenaxModelProvider";
  public int getProviderApiVersion() throws android.os.RemoteException;
  public java.lang.String[] getAvailableCapabilities() throws android.os.RemoteException;
  public void generate(dev.openksenax.addons.contract.model.ModelGenerationRequest request, dev.openksenax.addons.contract.model.IModelGenerationCallback callback) throws android.os.RemoteException;
  public void cancel(java.lang.String requestId) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
